public class EmpConst2
{
	int id; // instance variable
	String name;
	double sal;
	static int count=0;
	
	EmpConst2(int id, String name, double sal ) 
	{
		this.id=id;
		this.name=name;
		this.sal=sal;
		count++;
	}
    
	public void display()
	{ 
		  
		System.out.println(id+" "+name+" "+sal);
	}

	public static void main(String args[])
	{
		

		EmpConst2 e3=new EmpConst2(106,"Piyush",20000);
		
		e3.display();
 		System.out.println(EmpConst2.count);
	}



}