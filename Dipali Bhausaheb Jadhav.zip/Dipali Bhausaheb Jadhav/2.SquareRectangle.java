public class SquareRectangle
{
	public static void main(String args[])
	{
		int s=12;  //square
		int area_square=s*s;  //square
		int width=5;     //rectangle
		int height=6;   //rectangle
		int area=width*height;
		System.out.println("Area of the square="+area_square);
		System.out.println("Area of rectangle="+area);
	}
}