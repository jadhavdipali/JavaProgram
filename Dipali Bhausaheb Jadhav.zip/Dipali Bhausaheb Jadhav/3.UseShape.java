class Shape
{
	void print()
	{
		System.out.println("This is a Shape");
	}
}
class Rectangle extends Shape
{
	void print()
	{
		System.out.println("This is Rectangular Shape");
	}
}
class Circle extends Shape
{
	void print()
	{
		System.out.println("This is Circular Shape");
	}

}
public class UseShape
{
	public static void main(String args[])
	{
		Shape s = new Shape();
		s.print();
		Shape r = new Rectangle();
		r.print();
		Shape c = new Circle();
		c.print();
	}
}